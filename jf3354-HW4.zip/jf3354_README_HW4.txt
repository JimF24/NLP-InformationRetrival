README
To run: put everything in the same folder. 
in terminal: python3 jf3354-HW4.py

I use nltk to tokenize the sentences.
I use english stop words list in nltk.corpus as my stop words list.
For IDF calculation, I take the logarithm of the (quotient plus 1)
For TF, I do the straight count strategy and take the logarithm of (the count plus 1)
I tried to do stemming but stemming only decreases my score
